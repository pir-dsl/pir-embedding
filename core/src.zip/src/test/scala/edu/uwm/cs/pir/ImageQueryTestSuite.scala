package edu.uwm.cs.pir

import org.scalatest.FunSuite
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class DSLPrototypeSuite extends FunSuite {

//  val img = load[Image](Constants.WIKIPEDIA_IMAGES_ROOT, InputType.IMAGE)
//  val qImg = load[Image](Constants.WIKIPEDIA_ROOT + "/query.jpg", InputType.IMAGE)
//  val idx = index(f_luceneIdx, img.connect(f_cedd).connect(f_luceneDocTransformer), img.connect(f_fcth).connect(f_luceneDocTransformer))
//  val q = query(f_weightedQuery, idx, qImg)
//  
//  test("Connectivity test") {
//    assert(q != null)
//  }
}
