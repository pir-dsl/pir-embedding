package edu.uwm.cs.pir.domain.impl.lire

import edu.uwm.cs.pir.domain._
import edu.uwm.cs.pir.utils.AWSS3API._

import java.awt.image.BufferedImage
import java.io.IOException
import java.io.InputStream

import com.amazonaws.services.s3.AmazonS3

import edu.uwm.cs.mir.prototypes.feature.lire.LireFeatureAdaptor
import edu.uwm.cs.pir.utils.AWSS3API
import edu.uwm.cs.pir.utils.AWSS3API.AWSS3Config
import edu.uwm.cs.pir.utils.ImageUtils
import edu.uwm.cs.pir.utils.FileUtils

//TODO: Need to refactor the below
import edu.uwm.cs.mir.prototypes.feature.lire.utils.LireFeatureUtils
import edu.uwm.cs.mir.prototypes.feature.utils.FeatureUtils

case class Location(val url: String, val awsS3Config: AWSS3Config)

class LireImage(val p: Location) extends LireFeatureContainer[LireImage] {
  def getFeature: BufferedImage = {
    var image: BufferedImage = null
    try {
      if (p.awsS3Config.is_s3_storage) {
        println("get image from AWS S3")
        val amazonS3Client = AWSS3API.getAmazonS3Client(p.awsS3Config)
        val is = AWSS3API.getS3ObjectAsInputStream(p.awsS3Config, p.url, amazonS3Client, false)
        println("is=" + is)
        image = ImageUtils.readInputAsImage(is)
        println("image=" + image)
      } else {
        println("get image from file system")
        image = ImageUtils.readInputAsImage(p.url)
      }
    } catch {
      case ex: IOException => new RuntimeException(ex)

    }
    image
  }

  //override def compareTo(other: LireImage) = 1
}

case class LireText(val p: Location) extends LireFeatureContainer[LireText] {
  def getFeature: String = {
    var text: String = null
    if (p.awsS3Config.is_s3_storage) {
      val amazonS3Client = AWSS3API.getAmazonS3Client(p.awsS3Config)
      text = AWSS3API.getS3ObjectAsString(p.awsS3Config, p.url, amazonS3Client, false)
    } else {
      //println("get text from file system")
      try {
        text = FileUtils.readTextFile(p.url)
      } catch {
        case ex: IOException => new RuntimeException(ex)
      }
    }
    text
  }
}

trait LireFeature {
  def getFeature(image: LireImage, scaleWidth: Int, scaleHeight: Int) = {
    var bufferedImage = image.getFeature
    try {
      if (bufferedImage != null) {
        val imageType = if (bufferedImage.getType == 0) BufferedImage.TYPE_INT_ARGB else bufferedImage.getType
        bufferedImage = LireFeatureUtils.resizeImageWithHint(bufferedImage, imageType, scaleWidth, scaleHeight)
      }
    } catch {
      //When fail, we print out the exception and continue to process
      case ex: Exception => println(ex.getMessage())
    }
    bufferedImage
  }
}

case class LireCEDD(val scaleWidth: Int, val scaleHeight: Int) extends LireFeature with LireFeatureContainer[LireCEDD] {
  def getFeature(image: LireImage): net.semanticmetadata.lire.imageanalysis.CEDD = {
    val bufferedImage = super.getFeature(image, scaleWidth, scaleHeight)
    val lireFeature = new net.semanticmetadata.lire.imageanalysis.CEDD
    lireFeature.extract(bufferedImage)
    lireFeature
  }
}

case class LireFCTH(val scaleWidth: Int, val scaleHeight: Int) extends LireFeature with LireFeatureContainer[LireFCTH] {
  def getFeature(image: LireImage): net.semanticmetadata.lire.imageanalysis.FCTH = {
    val bufferedImage = super.getFeature(image, scaleWidth, scaleHeight)
    val lireFeature = new net.semanticmetadata.lire.imageanalysis.FCTH
    lireFeature.extract(bufferedImage)
    lireFeature
  }
}

case class LireColorLayout(val scaleWidth: Int, val scaleHeight: Int) extends LireFeature with LireFeatureContainer[LireColorLayout] {
  def getFeature(image: LireImage): net.semanticmetadata.lire.imageanalysis.ColorLayout = {
    val bufferedImage = super.getFeature(image, scaleWidth, scaleHeight)
    val lireFeature = new net.semanticmetadata.lire.imageanalysis.ColorLayout
    lireFeature.extract(bufferedImage)
    lireFeature
  }
}

case class LireFCTHEdgeHistogram(val scaleWidth: Int, val scaleHeight: Int) extends LireFeature with LireFeatureContainer[LireFCTHEdgeHistogram] {
  def getFeature(image: LireImage): net.semanticmetadata.lire.imageanalysis.EdgeHistogram = {
    val bufferedImage = super.getFeature(image, scaleWidth, scaleHeight)
    val lireFeature = new net.semanticmetadata.lire.imageanalysis.EdgeHistogram
    lireFeature.extract(bufferedImage)
    lireFeature
  }
}

case class LireFCTHGabor(val scaleWidth: Int, val scaleHeight: Int) extends LireFeature with LireFeatureContainer[LireFCTHGabor] {
  def getFeature(image: LireImage): net.semanticmetadata.lire.imageanalysis.Gabor = {
    val bufferedImage = super.getFeature(image, scaleWidth, scaleHeight)
    val lireFeature = new net.semanticmetadata.lire.imageanalysis.Gabor
    lireFeature.extract(bufferedImage)
    lireFeature
  }
}

case class LireSIFT() {
}

case class LireIndex() {
}

case class LireQuery() {
}

  